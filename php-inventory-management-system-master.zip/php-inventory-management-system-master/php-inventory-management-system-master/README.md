# Inventory Management System
Amzing Project on Management System
Check Demo Here : https://www.youtube.com/watch?v=9UZM8MmY1T8

-Open source inventory management system with php and mysql

-Invoice generation and easy to download invoice in PDF format

-Lightweight and easy to use

-Order management and product management can be done with ease

-Report management

-User wise sell report.

# Requirement

```
Need to change
store_url in db_connect.php

Login Credentials
Id : admin
password : admin
```
